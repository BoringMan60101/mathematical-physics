set terminal gif animate \
delay 100 %установили режим анимации со скоростью 10 кадров сек.
set output "HeatTransAnim.gif" %имя выходного файла
set font "Times New Roman,12" %выбор шрифта для подписей
set xlabel "x" %подпись оси Ox
set xrange [0:pi] %диапозон изменеия x
set ylabel "T(x)" %подпись оси Oy
set yrange [0:1] %диапозон изменеия y = T(x)
stats "data" name "File" %получили информацию о файле с данными
set nokey %убрали легенду
set title "Temperature T(x)" %подпись к анимации
%Цикл для покадрового построения анимации
do for [i=1:int(File_blocks)] { \
plot "../test_20_5_20/data" u 1:2 index i with linespoints lw 2 lc "red"}
