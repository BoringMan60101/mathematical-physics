/*

*/
#ifndef __CV_SOLVER__
#define __CV_SOLVER__
#include "my_types.hpp"

void checkMemAlloc(void *pointer, const char *ErrMsg);

//
extern void getPhysicsParamets(physConsts &Consts);

//
extern double ** getExactSolution(const discrMesh &mesh);

//
extern double * TDMA(double *T0, const discrMesh &mesh, const physConsts &constsm, uns t);
#endif
