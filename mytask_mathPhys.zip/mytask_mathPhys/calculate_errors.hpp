/*


*/

#ifndef __CALCULATE_ERRORS__
#define __CALCULATE_ERRORS__
#include "my_types.hpp"
#include <cmath>

void checkMemAlloc(void *pointer, const char *ErrMsg);

//
extern double * getAbsErr(double *curT_exact, double *curT, uns Np);

//
extern double getMaxAbsErr(double *curAbsErr, uns Np);

//
extern double T_exactFormula(const double time_layer, const double x);

//
extern double getAverageOfCurT_exact(double time_layer, double len);

//
extern double * getRelErr(double *curT_exact, double *curT, double time_layer, uns Np, double len);

//
extern double getMaxRelErr(double *curRelErr, uns Np);
#endif
