/*

*/

#include <cstdlib>
#include <cstdio>
#include "solver.hpp"
#include "my_types.hpp"
#include <cmath>

void checkMemAlloc(void *pointer, const char *ErrMsg);
extern void getPhysicsParamets(physConsts &Consts) {
  printf("Enter constant value of \'ro\' --> ");
  scanf("%lf", &(Consts.ro));
  printf("Enter constant value of \'c\' --> ");
  scanf("%lf", &(Consts.c));
  printf("Enter constant value of \'k\' --> ");
  scanf("%lf", &(Consts.k));
}

extern double ** getExactSolution(const discrMesh &mesh) {
  double ** T_exact = new double *[mesh.Nt+1]; //Массив хранит значения аналитического решения во всех рассчётных точках
  checkMemAlloc(T_exact, "Mem Error!\n In function \'T_exact\'\n");
  for(uns t = 0; t <= mesh.Nt; t++) {
    T_exact[t] = new double [mesh.Np];
    checkMemAlloc(T_exact[t], "Mem Error!\n In function \'T_exact\'\n");
    T_exact[t][0] = 0.0f; //Однородные граничные условия
    T_exact[t][mesh.Np-1] = 0.0f; //Однородные граничные условия
    for(uns i = 1; i <= mesh.Np-2; i++)
      T_exact[t][i] = (1.0f - exp(-mesh.cur_t[t]))*sin(mesh.Nodes[i]);
  }
  return T_exact;
}

extern double * TDMA(double *T0, const discrMesh &mesh, const physConsts &consts, uns t) {
  //для разности между узловыми точками в знаменателях при аппроксимации производных
  double dxW, dxE;
  double dFaces; //Разность между гранями очередного контрольного объема
  double fW, fE; //Значение восточной и западной грани (нужно при вычислении вклада источника)
  double aW, aP, aE, bP; //Коэффициенты для СЛАУ (на температуру) на каждом временном слое


  double *P, *Q, *T;
  T = new double [mesh.Np];
  P = new double [mesh.Np];
  Q = new double [mesh.Np];
  if(!(P && Q && T)) {
    fprintf(stderr, "%s\n", "Mem Error!\n In function \'TDMA\'\n");
    exit(EXIT_FAILURE);
  }

  P[0] = 0.0f;
  T[0] = Q[0] = 0.0f; //Задано однородное граничное условие первого рода
  //Прямой ход запоняет значениям массивы Q, P. На обратном ходе через них вычисляется T
  for(uns i = 1; i <= mesh.Np-2; i++) { //Вычисляем P[i], Q[i] для внутренних объёмов
    dxW = mesh.Nodes[i] - mesh.Nodes[i-1]; //Разность между узловыми точками
    dxE = mesh.Nodes[i+1] - mesh.Nodes[i];
    aW = (0.5f*consts.k) / dxW;
    aE = (0.5f*consts.k) / dxE;
    dFaces = mesh.Faces[i+1] - mesh.Faces[i]; //Разность между гранями очередного контрольного объема
    aP = (consts.ro*consts.c*dFaces)/mesh.dt[t] + aW + aE;
    fW = mesh.Faces[i]; //Восточная грань
    fE = mesh.Faces[i+1]; //Западная грань
    //!!!!dt(t)Вклад после интегрирования левой части
    bP = (consts.ro*consts.c*dFaces*T0[i])/mesh.dt[t];
    //Вклад после интегрирования конвективного члена по схеме Кранка-Николсона
    bP += aE*(T0[i+1] - T0[i]) - aW*(T0[i] - T0[i-1]);
    bP += -(cos(fE) - cos(fW)); //Вклад источника, который не зависит от времени
    P[i] = aE/(aP - aW*P[i-1]);
    Q[i] = (aW*Q[i-1] + bP) / (aP - aW*P[i-1]);
  }
  P[mesh.Np-1] = 0.0f;
  T[mesh.Np-1] = Q[mesh.Np-1] = 0.0f; //Задано однородное граничное условие первого рода

  //Обратный ход
  for(uns i = mesh.Np-2; i >= 1; i--)
    T[i] = P[i]*T[i+1] + Q[i];

  delete [] P; delete [] Q;
  return T;
}
