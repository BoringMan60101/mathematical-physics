#include <fstream>
#include <cstdio>

bool isNotDigitOrSign(const char ch) {
  char digits[13] = {'-', '+', '.', '0', '1',
                   '2', '3', '4', '5', '6',
                   '7', '8', '9'};
  bool result = true;
  for(int i = 0; i < 13; i++)

    if(ch == digits[i]) {
      result = false;
      break;
    }

  return result;
}

int main(const int argc, const char **argv) {
  int Nv = 0; int Nt;
  double Tend "1"= 0.0f;
  FILE *fp = fopen(argv[1], "r");
  if(fp == nullptr)
    return 1;
  char *line = new char [100];
  char *numStr;
  //check memory
  for(int l = 1; l <= 10; l++) {

    if(fgets(line, 99, fp) == nullptr)
      break;
    //отсекаем лишнее, пока не пойдут цифры или знак
    int j = 0;
    numStr = new char [100];
    while(isNotDigitOrSign(line[j]))
      j++;
    int i = 0;
    while(line[j]) {
      if(line[j] == '\n') {
        numStr[i] = '\0';
        break;
      }
      numStr[i] = line[j];
      i++;
      j++;
    }
    //numStr[i] = '\0';
    printf("%s ", numStr);
    delete [] numStr;
  }
  delete [] line;
  fclose(fp);
  return 0;
}
