/*
В данном файле реализованы функции для обработки файла, где заданны
иходные данные задачи. А также функции для вывода результатов в файлы
*/

#include "my_types.hpp"
#include <cstdlib>
#include <cstdio>

void checkMemAlloc(void *pointer, const char *ErrMsg);

static bool isDigitOrSign(const char ch) {
  char digits[13] = { '-', '+', '.', '0', '1',
                      '2', '3', '4', '5', '6',
                      '7', '8', '9'};
  bool result = false;
  for(int i = 0; i < 13; i++)
    if(ch == digits[i]) {
      result = true;
      break;
    }
  return result;
}

extern int getCaseParameters(const char *fileName, physConsts & consts, discrMesh & mesh) {
  uns maxSize = 100; //Максимальная длина для считывания строки
  uns l = 0; //число считанных строк
  uns paramsNum = 6; //Сколько параметров должно быть файле (каждый в отдельной строке)
  FILE *fp = fopen(fileName, "r");
  if(fp == nullptr)
    return 1;
  char *line = new char [maxSize]; //Обработка файла происходит построчно
  checkMemAlloc(line, "Error with memory alloction in function \"getCaseParameters\"\n");
  char *numStr; //В неё заносится число в виде набора символов


  while(1) {
    if(fgets(line, maxSize-1, fp) == nullptr) {
      //Проверка: все строки считаны
      //и их число не совпало с предполагаемым числом параметров
      if(l != paramsNum+1)
        return 2;
      break;
    }
    l += 1; //Увеличение счётчика считанных строк
    int j = 0; //Индекс символа в текущей считанной строке
    numStr = new char [maxSize];
    checkMemAlloc(numStr, "Error with memory alloction in function \"getCaseParameters\"\n");
    //Отсечение лишних символов, до первой цифры или знака (+/-/.)
    while(isDigitOrSign(line[j]) == false)
      j++;

    //Индекс в строке, куда посимвольо будет записано число
    //это число - один из параметров задачи
    int i = 0;
    while(line[j]) {
      if(line[j] == '\n') {
        numStr[i] = '\0';
        break;
      }
      numStr[i] = line[j];
      i++; j++;
    }

    switch (l) {
      case 1: { mesh.Nv = atoi(numStr); break; }
      case 2: { mesh.T_end = atof(numStr); break; }
      case 3: { mesh.Nt = atoi(numStr); break; }
      case 4: { consts.ro = atof(numStr); break; }
      case 5: { consts.c = atof(numStr); break; }
      case 6: { consts.k = atof(numStr); break; }
      //Если строк больше, чем предполагается, то обработка завершается
      default: { delete [] line; delete [] numStr; fclose(fp); return 3; }
    }
    delete [] numStr;
  }
  delete [] line;
  fclose(fp);
  return 0;
}


extern void printDataToFile(const discrMesh &mesh, double *curT_exact, double *curT) {
  static bool first = true;
  FILE * fp = fopen("data", "a+");
  if(fp == nullptr) {
    printf("Erorr with opening file to write data\n");
    exit(EXIT_FAILURE);
  }
  if(first) {
    fprintf(fp, "#   X   T_exact   T\n");
    fclose(fp);
    first = false;
    return;
  }
  for(uns i = 0; i < mesh.Np; i++)
    fprintf(fp, "%lf %lf %lf\n", mesh.Nodes[i], curT_exact[i], curT[i]);
  fprintf(fp, "\n\n"); //Разделение между данными на кажом слое в две пустых строки
  fclose(fp);
}

extern void printErrorsOnTimeLayerToFile(const discrMesh &mesh, const errors &errs, uns t) {
  static bool first = true;
  FILE * fp = fopen("errors", "a+");
  if(fp == nullptr) {
    printf("Erorr with opening file to write errors\n");
    exit(EXIT_FAILURE);
  }
  if(first) {
    fprintf(fp, "# time   X   AbsErr   RelErr\n");
    fclose(fp);
    first = false;
    return;
  }
  for(uns i = 0; i < mesh.Np; i++)
    fprintf(fp, "%lf %lf %lf\n", mesh.Nodes[i], errs.abs[i], errs.rel[i]);
  fprintf(fp, "\n"); //Разделение между слоями в две пустых строки
  fclose(fp);
}

extern void printMaxErrorsToFile(const discrMesh &mesh, const errors &errs, uns t) {
  static bool first = true;
  FILE * fp = fopen("MaxErrors", "a+");
  if(fp == nullptr) {
    printf("Erorr with opening file to write errors\n");
    exit(EXIT_FAILURE);
  }
  if(first) {
    fprintf(fp, "time    MaxAbs   MaxRel\n");
    fclose(fp);
    first = false;
    return;
  }
  //fprintf(fp, "%e %e %e\n", mesh.cur_t[t], errs.maxAbs, errs.maxRel);
  fprintf(fp, "%lf %lf %lf\n", mesh.cur_t[t], errs.maxAbs, errs.maxRel);
  fclose(fp);
}
